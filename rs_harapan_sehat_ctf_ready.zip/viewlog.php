<?php
$f = $_GET['filename'] ?? 'access.log';
$path = __DIR__ . '/' . $f;
if(file_exists($path)){ echo "<pre>".htmlspecialchars(file_get_contents($path))."</pre>"; }
else echo "Not found";
?>