<?php
$q = $_GET['q'] ?? '';
$conn = new mysqli('db','root',getenv('MYSQL_ROOT_PASSWORD')?:'rootpass','rs_harapan_sehat');
$ok = $conn->query("SELECT COUNT(*) as c FROM schedules WHERE hari='$q'");
$c = $ok ? $ok->fetch_assoc()['c'] : 0;
?>
<div class="card card-ct p-4 mb-3">
<h4>Jadwal Dokter</h4>
<form><input name="q" class="form-control mb-2" placeholder="hari (Senin)"><button class="btn btn-primary">Cek</button></form>
<div class="mt-2">Ada? <?php echo $c>0 ? 'Yes' : 'No'; ?></div>
</div>