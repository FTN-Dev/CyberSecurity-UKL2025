<?php
$mysqli = new mysqli(getenv('DB_HOST')?:'db','root',getenv('MYSQL_ROOT_PASSWORD')?:'rootpass','rs_harapan_sehat');
if(!$mysqli->connect_errno){
    if($_SERVER['REQUEST_METHOD']==='POST'){
        $n=$mysqli->real_escape_string($_POST['name']);
        $m=$_POST['message']; // intentionally not escaped to allow stored XSS
        $mysqli->query("INSERT INTO feedback(name,message) VALUES('$n','".$m."')");
    }
    $res = $mysqli->query("SELECT * FROM feedback ORDER BY id DESC");
}
?>
<div class="card card-ct p-4 mb-3">
<h4>Kritik & Saran</h4>
<form method="post">
<input name="name" class="form-control mb-2" placeholder="Nama"><textarea name="message" class="form-control mb-2" placeholder="Pesan"></textarea>
<button class="btn btn-success">Kirim</button>
</form>
<hr>
<?php
if(isset($res)){
while($r=$res->fetch_assoc()){
    echo "<div class='mb-2'><strong>".htmlspecialchars($r['name'])."</strong><div>".$r['message']."</div></div>";
}
}
?>
</div>