<?php
// Vulnerable include page
$pagefile = $_GET['pagefile'] ?? 'home.php';
// Intentionally vulnerable: no sanitization
if (strpos($pagefile, 'http') === 0) {
    // remote include allowed (for CTF)
    @include($pagefile);
} else {
    @include($pagefile);
}
?>