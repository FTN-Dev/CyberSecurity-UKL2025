<?php
$ann = $_GET['ann'] ?? 'Selamat datang di RS Harapan Sehat';
$blocked = str_ireplace(array('<script>','</script>','<script','script>'),'',$ann');
?>
<div class="card card-ct p-4 mb-3">
<h4>Pengumuman</h4>
<form><input name="ann" class="form-control" value="<?php echo htmlspecialchars($ann); ?>"><button class="btn btn-primary mt-2">Tampilkan</button></form>
<hr>
<div><?php echo $blocked; ?></div>
</div>