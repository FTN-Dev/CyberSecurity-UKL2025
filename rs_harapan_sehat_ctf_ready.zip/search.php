<?php
$q = $_GET['q'] ?? '';
?>
<div class="card card-ct p-4 mb-3">
<h4>Cari Pasien</h4>
<form method="get">
<input type="hidden" name="page" value="search">
<div class="mb-2"><input name="q" class="form-control" placeholder="nama pasien"></div>
<button class="btn btn-primary">Cari</button>
</form>
<?php
if($q!==''){
    echo "<div class='mt-3'>Hasil pencarian untuk: <strong>" . $q . "</strong></div>";
    echo "<div class='flag'>Flag (jika XSS berhasil, tampilkan JS)</div>";
}
?>
</div>