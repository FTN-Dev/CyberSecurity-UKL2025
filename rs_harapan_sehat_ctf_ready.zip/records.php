<?php
$id = $_GET['id'] ?? '1';
$conn = new mysqli('db','root',getenv('MYSQL_ROOT_PASSWORD')?:'rootpass','rs_harapan_sehat');
$q = "SELECT * FROM patients WHERE id=$id";
$res = $conn->query($q);
if(!$res){ echo "<div class='alert alert-warning'>SQL Error: ".$conn->error."</div>"; }
else{
 while($r=$res->fetch_assoc()){
   echo "<div class='card card-ct p-3 mb-2'><h5>".$r['nama']."</h5></div>";
 }
}
?>