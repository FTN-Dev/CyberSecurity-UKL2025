<div class="card card-ct p-4 mb-3">
<h4>Profil Pasien</h4>
<p>Nama: Joni</p>
<div id="info"></div>
<script>
let h = location.hash.substring(1);
document.getElementById('info').innerHTML = "Info tambahan: " + h;
</script>
</div>